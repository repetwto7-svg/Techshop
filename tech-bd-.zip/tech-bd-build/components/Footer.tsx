import Link from 'next/link';
export default function Footer(){return <footer className="container footer"><Link href="/" className="brand">TECH <span>BD</span></Link><span>© {new Date().getFullYear()} Tech BD.</span><span><Link href="/shop">Shop</Link> · <Link href="/cart">Cart</Link> · <Link href="/login">Login</Link></span></footer>}
