'use client';
import Link from 'next/link';
import { ShoppingBag } from 'lucide-react';
import { useEffect, useState } from 'react';
import { cartCount } from '@/lib/cart';
export default function Header() {
 const [count,setCount] = useState(0);
 useEffect(()=>{ const update=()=>setCount(cartCount()); update(); window.addEventListener('storage',update); window.addEventListener('techbd-cart-updated',update); return ()=>{window.removeEventListener('storage',update);window.removeEventListener('techbd-cart-updated',update)}; },[]);
 return <header className="container nav"><Link href="/" className="brand">TECH <span>BD</span></Link><nav className="navlinks"><Link href="/shop">Shop</Link><Link className="optional" href="/#why">Why Tech BD</Link><Link className="pill" href="/cart"><ShoppingBag size={15} style={{display:'inline',verticalAlign:'middle',marginRight:6}}/>Cart <span className="cart-count">({count})</span></Link><Link className="optional" href="/login">Login</Link></nav></header>;
}
