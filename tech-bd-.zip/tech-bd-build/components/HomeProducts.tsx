'use client';
import ProductCard from './ProductCard';
import { useProducts } from '@/lib/use-products';
export default function HomeProducts(){const {products}=useProducts();return <div className="products">{products.filter(p=>p.featured).map(p=><ProductCard key={p.id} product={p}/>)}</div>}
