'use client';
import Link from 'next/link';
import { useState } from 'react';
import type { Product } from '@/lib/products';
import { addCartItem } from '@/lib/cart';
export default function ProductCard({ product }: { product: Product }) {
 const [added,setAdded]=useState(false);
 const add=()=>{addCartItem(product.id);window.dispatchEvent(new Event('techbd-cart-updated'));setAdded(true);setTimeout(()=>setAdded(false),1200)};
 return <article className="product"><Link href={`/products/${product.id}`} aria-label={`View ${product.name}`} className="product-image">{product.image?<img src={product.image} alt={product.name}/>:<span>{product.icon}</span>}</Link><small>{product.category.toUpperCase()}</small><h3><Link href={`/products/${product.id}`}>{product.name}</Link></h3><p>{product.description}</p><div className="product-bottom"><div className="price">৳{product.price}<br/><span>{product.duration}</span></div><button className="buy" onClick={add}>{added?'Added ✓':'Add to cart'}</button></div><Link className="details-link" href={`/products/${product.id}`}>View details →</Link></article>
}
