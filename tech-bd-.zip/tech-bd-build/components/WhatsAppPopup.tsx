'use client';

import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

const WHATSAPP_NUMBER = '8801640085064';
const DEFAULT_MESSAGE = 'Assalamu Alaikum! I need help with Tech BD products.';

export default function WhatsAppPopup() {
  const [open, setOpen] = useState(false);
  const chatUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(DEFAULT_MESSAGE)}`;

  return (
    <div className="wa-widget" aria-label="WhatsApp support">
      {open && (
        <section className="wa-card" role="dialog" aria-label="Chat with Tech BD on WhatsApp">
          <div className="wa-card-head">
            <span className="wa-avatar"><MessageCircle size={22} /></span>
            <div className="wa-head-copy">
              <strong>Tech BD Support</strong>
              <span><i className="wa-online-dot" /> Usually replies on WhatsApp</span>
            </div>
            <button className="wa-close" onClick={() => setOpen(false)} aria-label="Close WhatsApp popup"><X size={18} /></button>
          </div>
          <div className="wa-card-body">
            <p>আসসালামু আলাইকুম! 👋</p>
            <p>কোনো প্রোডাক্ট বা অর্ডার নিয়ে সাহায্য লাগলে আমাদের WhatsApp-এ মেসেজ দিন।</p>
            <span className="wa-number">+880 1640-085064</span>
          </div>
          <a className="wa-start-chat" href={chatUrl} target="_blank" rel="noopener noreferrer">
            <Send size={17} /> Start WhatsApp Chat
          </a>
        </section>
      )}
      <button className={`wa-fab${open ? ' wa-fab-open' : ''}`} onClick={() => setOpen(v => !v)} aria-label={open ? 'Close WhatsApp support' : 'Open WhatsApp support'} aria-expanded={open}>
        {open ? <X size={25} /> : <MessageCircle size={27} />}
        {!open && <span className="wa-fab-pulse" />}
      </button>
    </div>
  );
}
