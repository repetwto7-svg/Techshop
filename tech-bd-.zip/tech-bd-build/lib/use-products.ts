'use client';
import { useEffect, useState } from 'react';
import { products as fallback, type Product } from './products';
import { getSupabase } from './supabase';
export function useProducts() {
 const [items,setItems]=useState<Product[]>(fallback);
 const [loaded,setLoaded]=useState(false);
 useEffect(()=>{ let alive=true; const supabase=getSupabase(); if(!supabase){setLoaded(true);return;}
  supabase.from('products').select('*').order('id').then(({data,error})=>{if(alive&&!error&&data){setItems(data as Product[])}setLoaded(true)});
  return ()=>{alive=false};
 },[]);
 return { products: items, loaded };
}
