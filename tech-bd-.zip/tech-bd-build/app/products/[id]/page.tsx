'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductDetail from './product-detail';
import { useProducts } from '@/lib/use-products';

export default function ProductPage() {
  const params = useParams<{ id: string }>();
  const { products, loaded } = useProducts();
  const product = products.find((p) => String(p.id) === String(params.id) || p.slug === String(params.id));
  return <main><Header /><section className="container section page-top">
    {product ? <><p className="breadcrumbs"><Link href="/">Home</Link> / <Link href="/shop">Shop</Link> / {product.name}</p><ProductDetail product={product} /></> : loaded ? <div className="empty-state"><h1>Product not found</h1><Link className="primary" href="/shop">Back to shop</Link></div> : <p className="lead">Loading product…</p>}
  </section><Footer /></main>;
}
