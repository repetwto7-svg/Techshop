import Header from '@/components/Header';import Footer from '@/components/Footer';import ShopGrid from '@/components/ShopGrid';
export default function ShopPage(){return <main><Header/><section className="container section page-top"><div className="section-head"><div><h1>Shop all products</h1><p>Search and filter the Tech BD catalogue.</p></div></div><ShopGrid/></section><Footer/></main>}
