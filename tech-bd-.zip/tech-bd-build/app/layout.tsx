import type { Metadata } from "next";
import "./globals.css";
import WhatsAppPopup from "@/components/WhatsAppPopup";

export const metadata: Metadata = {
  title: "Tech BD — Digital Products",
  description: "Discover digital tools and subscriptions at Tech BD.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}<WhatsAppPopup /></body></html>;
}
