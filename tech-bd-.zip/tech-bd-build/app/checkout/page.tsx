'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useProducts } from '@/lib/use-products';
import { readCart, type CartLine } from '@/lib/cart';

const BKASH_NUMBER = '01640085064';

export default function CheckoutPage() {
  const { products } = useProducts();
  const [cart, setCart] = useState<CartLine[]>([]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'banglaqr'>('bkash');
  const [transactionId, setTransactionId] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => setCart(readCart()), []);
  const lines = cart.map(x => ({ ...x, product: products.find(p => p.id === x.productId) })).filter(x => x.product);
  const total = lines.reduce((s, x) => s + (x.product?.price || 0) * x.quantity, 0);

  const orderText = `TECH BD ORDER REQUEST
Name: ${name}
Phone: ${phone}
Email: ${email}
Payment method: ${paymentMethod === 'bkash' ? 'bKash Send Money' : 'Bangla QR'}
${paymentMethod === 'bkash' ? `bKash number: ${BKASH_NUMBER}` : 'Payment QR: Bangla QR'}
Transaction ID: ${transactionId}
Items:
${lines.map(x => `${x.product?.name} x ${x.quantity} — ৳${(x.product?.price || 0) * x.quantity}`).join('\n')}
Total: ৳${total}
Notes: ${notes}`;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitted(true);
  }

  return <main><Header /><section className="container section page-top">
    <h1>Checkout</h1>
    <p className="lead">অর্ডার ও পেমেন্টের তথ্য পূরণ করুন।</p>
    {lines.length === 0 ? <div className="empty-state"><h2>কার্টে কোনো পণ্য নেই</h2><Link className="primary" href="/shop">Shop দেখুন</Link></div>
    : submitted ? <div className="success-panel">
      <h2>Order request prepared ✓</h2>
      <p>এই ডেমো সাইট অর্ডার সার্ভারে পাঠায় না বা পেমেন্ট যাচাই করে না। নিচের তথ্য কপি করে বিক্রেতাকে পাঠান।</p>
      <textarea className="search order-text" readOnly value={orderText} />
      <button className="primary" onClick={() => navigator.clipboard?.writeText(orderText)}>Copy order details</button>
      <p><Link href="/shop">Shop-এ ফিরে যান</Link></p>
    </div>
    : <div className="checkout-layout">
      <form className="checkout-form" onSubmit={submit}>
        <label>আপনার নাম<input className="search" value={name} onChange={e => setName(e.target.value)} required placeholder="আপনার নাম" /></label>
        <label>ফোন নম্বর<input className="search" value={phone} onChange={e => setPhone(e.target.value)} required placeholder="01XXXXXXXXX" inputMode="tel" /></label>
        <label>Email (ঐচ্ছিক)<input className="search" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" /></label>

        <fieldset className="payment-fieldset">
          <legend>পেমেন্ট মেথড নির্বাচন করুন</legend>
          <label className={`payment-option ${paymentMethod === 'bkash' ? 'selected' : ''}`}>
            <input type="radio" name="paymentMethod" value="bkash" checked={paymentMethod === 'bkash'} onChange={() => setPaymentMethod('bkash')} />
            <span><strong>bKash</strong><small>Send Money</small></span>
          </label>
          <label className={`payment-option ${paymentMethod === 'banglaqr' ? 'selected' : ''}`}>
            <input type="radio" name="paymentMethod" value="banglaqr" checked={paymentMethod === 'banglaqr'} onChange={() => setPaymentMethod('banglaqr')} />
            <span><strong>বাংলা QR</strong><small>QR স্ক্যান করে পেমেন্ট</small></span>
          </label>
        </fieldset>

        {paymentMethod === 'bkash' ? <div className="payment-detail">
          <h3>bKash Send Money</h3>
          <p>এই নম্বরে Send Money করুন:</p>
          <div className="payment-number">{BKASH_NUMBER}</div>
          <button type="button" className="buy" onClick={() => navigator.clipboard?.writeText(BKASH_NUMBER)}>নম্বর কপি করুন</button>
          <p className="muted-small">পেমেন্টের পর Transaction ID নিচে লিখুন।</p>
        </div> : <div className="payment-detail">
          <h3>বাংলা QR পেমেন্ট</h3>
          <p>আপনার পেমেন্ট অ্যাপ দিয়ে নিচের QR কোড স্ক্যান করুন।</p>
          <img className="bangla-qr-image" src="/products/bangla-qr.jpeg" alt="Bangla QR payment code" />
          <p className="muted-small">স্ক্যান করার আগে আপনার পেমেন্ট অ্যাপে প্রাপকের তথ্য ও পরিমাণ যাচাই করুন।</p>
        </div>}

        <label>Transaction ID<input className="search" value={transactionId} onChange={e => setTransactionId(e.target.value)} required placeholder="পেমেন্টের Transaction ID লিখুন" /></label>
        <label>অর্ডার নোট (ঐচ্ছিক)<textarea className="search" value={notes} onChange={e => setNotes(e.target.value)} placeholder="অতিরিক্ত তথ্য" rows={3} /></label>
        <button className="primary" type="submit">অর্ডার তথ্য তৈরি করুন</button>
        <p className="muted-small">এই ফর্ম অর্ডার সার্ভারে পাঠায় না এবং পেমেন্ট স্বয়ংক্রিয়ভাবে যাচাই করে না।</p>
      </form>
      <aside className="cart-summary"><h2>Order summary</h2>
        {lines.map(x => <div className="summary-line" key={x.productId}><span>{x.product?.name} × {x.quantity}</span><b>৳{(x.product?.price || 0) * x.quantity}</b></div>)}
        <div className="summary-total"><span>Total</span><strong>৳{total}</strong></div>
        <Link href="/cart">কার্ট পরিবর্তন করুন</Link>
      </aside>
    </div>}
  </section><Footer /></main>;
}
