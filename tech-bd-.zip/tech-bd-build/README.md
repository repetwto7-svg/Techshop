# Tech BD — multi-page storefront starter

This version keeps the existing dark + neon green Tech BD storefront style and adds working navigation between Home, Shop, Product Details, Cart, Checkout and Login preview pages.

## Run / deploy
- Import the repository into Vercel with the default Next.js settings.
- Run `npm install`, then `npm run build` to verify.

## Edit product posts and images
- Edit `lib/products.ts` to change product name, price, category, duration and description.
- Upload each product image into `public/products/` (example: `public/products/canva-pro.jpg`).
- In that product entry set `image: '/products/canva-pro.jpg'`.
- If no image path is provided, the card displays its icon instead.

## Important limitations
- Cart is stored in the visitor's browser (localStorage); it is not a server-side order database.
- Checkout prepares an order request locally and can copy its details, but does not submit orders to a business or collect payments.
- Login is a UI preview, not real authentication.
- Add a secure backend, authentication provider, order database and approved payment provider before accepting real orders.
- Only list digital subscriptions/licenses you are authorized to resell.


## Secure Admin Panel (required setup)
The admin route is `/admin`. Product editing uses Supabase Auth + Postgres and Row Level Security. No admin password or service-role key is embedded in the website.

### 1. Create Supabase project
Create a project at https://supabase.com. In Project Settings → API, copy the Project URL and the publishable/anon key. In Vercel → Project → Settings → Environment Variables, add:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
Redeploy after adding variables. For local development, copy `.env.example` to `.env.local` and fill values.

### 2. Create database tables
Open Supabase → SQL Editor and run the full SQL in `supabase/schema.sql`.

### 3. Create the admin account securely
In Supabase → Authentication → Users, create a user with your own email and a strong password. Copy that user's UUID. Then run this SQL in SQL Editor, replacing `PASTE_AUTH_USER_UUID` with the actual UUID:
`insert into public.admins (user_id) values ('PASTE_AUTH_USER_UUID');`
Do not add public sign-up to the storefront. Only UUIDs in `public.admins` are allowed to edit products.

### 4. Deploy
Upload the ZIP contents (the files inside `tech-bd-build`, not an extra enclosing folder) to the existing GitHub repository, commit to `main`, then wait for Vercel to build. Open `https://YOUR-DOMAIN/admin` and sign in with the Supabase admin user.

### Notes
- The storefront keeps the existing local product list as a fallback if Supabase is not configured. The admin database is persistent after the SQL/env setup.
- Do not put a Supabase `service_role` secret in any `NEXT_PUBLIC_` variable or client-side file.
- Image field accepts a URL or a path under `public/products/`; this starter does not upload image files to Supabase Storage directly.
- Admin updates are persisted in Supabase. To have the public catalogue read the database, the schema allows public product reads; re-deploy after environment variable changes.
- Checkout and payment are not real payment processing or automatic transaction verification.
